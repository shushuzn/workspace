@echo off
REM ========================================
REM WORKFLOW - Unified Workflow Entry Point
REM ========================================
REM Usage:
REM   workflow.bat              - Show help
REM   workflow.bat list         - List all workflows
REM   workflow.bat dev          - Run dev workflow
REM   workflow.bat run <name>   - Run specific workflow
REM   workflow.bat categories   - List by category

setlocal enabledelayedexpansion

set "CMD=%1"

if "%CMD%"=="" goto :help
if "%CMD%"=="help" goto :help
if "%CMD%"=="-h" goto :help
if "%CMD%"=="--help" goto :help

if "%CMD%"=="list" goto :list
if "%CMD%"=="categories" goto :categories
if "%CMD%"=="agent" goto :agent
if "%CMD%"=="multi-agent" goto :agent

if "%CMD%"=="viz" goto :viz
if "%CMD%"=="visualize" goto :viz

if "%CMD%"=="run" (
    set "WF=%2"
    if "!WF!"=="" (
        echo ERROR: Missing workflow name
        echo Usage: workflow.bat run ^<workflow-name^>
        exit /b 1
    )
    goto :run
)

REM Direct workflow run
set "WF=%CMD%"
goto :run

:run
echo.
echo ========================================
echo Running workflow: %WF%
echo ========================================
python 30-scripts-tools\workflow_master_001.py --run %WF%
exit /b %ERRORLEVEL%

:list
echo.
echo ========================================
echo Available Workflows
echo ========================================
python 30-scripts-tools\workflow_master_001.py --list
exit /b 0

:categories
echo.
echo ========================================
echo Workflow Categories
echo ========================================
python 30-scripts-tools\workflow_master_001.py --categories
exit /b 0

:agent
set "TASK=%~2"
if "!TASK!"=="" (
    echo.
    echo ========================================
    echo Multi-Agent Collaboration
    echo ========================================
    python 30-scripts-tools\multi_agent_orchestrator_001.py --viz
    echo.
    echo Run task:
    echo   workflow.bat agent "your task"
) else (
    python 30-scripts-tools\multi_agent_orchestrator_001.py !TASK!
)
exit /b 0

:viz
echo.
echo ========================================
echo Multi-Agent Visualization
echo ========================================
python 30-scripts-tools\multi_agent_orchestrator_001.py --viz
exit /b 0

:help
echo.
echo ========================================
echo WORKFLOW - Unified Workflow Entry Point
echo ========================================
echo.
echo Usage:
echo   workflow.bat              - Show this help
echo   workflow.bat list         - List all workflows
echo   workflow.bat categories   - List by category
echo   workflow.bat dev          - Run dev workflow
echo   workflow.bat run ^<name^> - Run specific workflow
echo   workflow.bat agent        - Multi-Agent status
echo   workflow.bat viz          - Agent visualization
echo.
echo Categories:
echo   dev       - Development workflows
echo   plan      - Planning workflows
echo   qa        - Quality Assurance
echo   ops       - Operations
echo   research  - Research pipelines
echo   agent     - Multi-Agent collaboration
echo.
echo Examples:
echo   workflow.bat dev
echo   workflow.bat plan
echo   workflow.bat agent
echo   workflow.bat agent "优化代码"
exit /b 0
